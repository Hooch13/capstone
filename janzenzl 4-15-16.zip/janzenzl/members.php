<?PHP  session_start();
	include("nav.php");
	include("ryan_library.php");
	$max_length = 16;
	?>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/membersarea.css">
	
	<?PHP 
	$userQuery = "SELECT * FROM tUser";
	$results = $dbc->query($userQuery);
	echo "<h2>Members List</h2>"; 
	while($row = $results->fetch_array())
	{
		$UploadCountQuery = "SELECT * FROM tAssignment WHERE UserID = ". $row["UserID"];
		//echo "<!--" . $UploadCountQuery . "-->";
		$countResult = $dbc->query($UploadCountQuery);
		$count = $countResult->num_rows;
		if(strlen($row['Bio']) > $max_length){ $bio_out = substr($row['Bio'],0, $max_length);
								  $bio_out .= "...";
								 } else { $bio_out = $row['Bio'];  } 
		$MemberDisplay = '<div class="UserBlock">
							<div class="UserImage">
								<img src="images/placeholder.png" alt="Coming Soon">
							</div>
							 
							<div class="userInfoBoxes"><span class="UserInfoLabel">Name</span>
								<span class="UserInfoLabel">'. $row['FirstName'].' '.$row['LastName'].' </span> </div>
							<div class="userInfoBoxes"><span class="UserInfoLabel">Bio</span> 
							     <span class="UserInfoLabel">'. $bio_out .'</span></div>
							<div class="userInfoBoxes"><span class="UserInfoLabel"># of Uploads</span>
								<span class="UserInfoLabel">'. $count.'</span>
								</div>
							<a href="view.php?rid='. $row['UserID'] .'" class="userInfoProfileButton">View Profile</a>
						</div>';

		echo $MemberDisplay;
	}
?>