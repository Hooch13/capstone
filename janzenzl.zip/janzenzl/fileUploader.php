<?php
include("loginCheck.php");
include("nav.php");
include("db_connect.php");
?>

<div class="container">
    <div class="jumbotron">
       <h1>File Uploader</h1>
    </div>
    <?php
$target_dir = "assignments/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$theFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if(isset($_POST["submit"])) {
    $uploadOk = 1;
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "<div class='alert alert-danger text-center'>" . "Sorry, file already exists." . "</div>";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "<div class='alert alert-danger text-center'>" . "Sorry, your file is too large." . "</div>";
    $uploadOk = 0;
}
// Allow certain file formats
if($theFileType != "zip") {
    echo "<div class='alert alert-danger text-center'>" . "Sorry, only ZIP files are allowed." . "</div>";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "<div class='alert alert-danger text-center'>" . "Sorry, your file was not uploaded." . "</div>";
    // if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "<div class='alert alert-success text-center'> The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded. </div>";
    } else {
        echo "<div class='alert alert-danger text-center'>" . "Sorry, there was an error uploading your file." . "</div>";
    }
}
?>
</div>