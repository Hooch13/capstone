<?PHP
include("loginCheck.php");
include("nav.php");
include("db_connect.php");
// end session login
?>
<html xmlns="http://www.w3.org/1999/html">
<body></body>
<div class="container">
    <h2>Upload</h2>
    <div class="panel panel-default">
        <div class="panel-heading">
            Class you're teaching:
        </div>
        <div class ="panel-body">

            <div class="col-sm-4">

                <div class="form-group">
                    <label for="sel2">Subject:</label>
                    <select multiple class="form-control" id="sel2">
                        <?php
                        $pSubjectQuery = "SELECT * FROM Primary_Subjects ORDER BY Subject ASC";
                        $results = $dbc->query($pSubjectQuery);
                        echo $pSubjectQuery;
                        while($row = $results->fetch_array())
                        {
                            //echo "<tr>";
                            // echo "<td class='rowID'>". $row["app_id"] . "</td>";
                            echo "<option>". $row["Subject"] .  "</option>";
                            //echo "<td>". $row["CompletedDate"] . "</td>";
                            //echo "<td> <a style='text-decoration: none; color: red;' href='mailto:". $row["EMail1"] . "'/a>". $row["EMail1"]."</td>";
                            //echo "<td style='border-bottom: none;'><a class ='viewButton' href='app.php?record=". $row["app_id"] . "' target='viewer'>View</a></td>";
                            //echo "</tr>";
                        }
                        ?>
                    </select>
                </div>

            </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label for="sel2">Specialty:</label>
                    <select multiple class="form-control" id="sel2">
                        <?php
                        $pSpecialtyQuery = "SELECT * FROM Primary_Specialties ORDER BY Specialty ASC";
                        $results = $dbc->query($pSpecialtyQuery);
                        echo $pSpecialtyQuery;
                        while($row = $results->fetch_array())
                        {
                            //echo "<tr>";
                            // echo "<td class='rowID'>". $row["app_id"] . "</td>";
                            echo "<option>" . $row["Specialty"] .  "</option>";
                            //echo "<td>". $row["CompletedDate"] . "</td>";
                            //echo "<td> <a style='text-decoration: none; color: red;' href='mailto:". $row["EMail1"] . "'/a>". $row["EMail1"]."</td>";
                            //echo "<td style='border-bottom: none;'><a class ='viewButton' href='app.php?record=". $row["app_id"] . "' target='viewer'>View</a></td>";
                            //echo "</tr>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label for="sel2">Course:</label>
                    <select multiple class="form-control" id="sel2">
                        <?php
                        $pCourseQuery = "SELECT * FROM Primary_Courses ORDER BY Course ASC";
                        $results = $dbc->query($pCourseQuery);
                        echo $pCourseQuery;
                        while($row = $results->fetch_array())
                        {
                            //echo "<tr>";
                            // echo "<td class='rowID'>". $row["app_id"] . "</td>";
                            echo "<option>" . $row["Course"] .  "</option>";
                            //echo "<td>". $row["CompletedDate"] . "</td>";
                            //echo "<td> <a style='text-decoration: none; color: red;' href='mailto:". $row["EMail1"] . "'/a>". $row["EMail1"]."</td>";
                            //echo "<td style='border-bottom: none;'><a class ='viewButton' href='app.php?record=". $row["app_id"] . "' target='viewer'>View</a></td>";
                            //echo "</tr>";
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="panel-heading">
            With your assignment being focused on:
        </div>
        <div class ="panel-body">
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="sel2">Subject:</label>
                    <select multiple class="form-control" id="sel2">
                        <?php
                        $pSubjectQuery = "SELECT * FROM Primary_Subjects ORDER BY Subject ASC";
                        $results = $dbc->query($pSubjectQuery);
                        echo $pSubjectQuery;
                        while($row = $results->fetch_array())
                        {
                            //echo "<tr>";
                            // echo "<td class='rowID'>". $row["app_id"] . "</td>";
                            echo "<option>". $row["Subject"] .  "</option>";
                            //echo "<td>". $row["CompletedDate"] . "</td>";
                            //echo "<td> <a style='text-decoration: none; color: red;' href='mailto:". $row["EMail1"] . "'/a>". $row["EMail1"]."</td>";
                            //echo "<td style='border-bottom: none;'><a class ='viewButton' href='app.php?record=". $row["app_id"] . "' target='viewer'>View</a></td>";
                            //echo "</tr>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="sel2">Specialty:</label>
                    <select multiple class="form-control" id="sel2">
                        <?php
                        $pSpecialtyQuery = "SELECT * FROM Primary_Specialties ORDER BY Specialty ASC";
                        $results = $dbc->query($pSpecialtyQuery);
                        echo $pSpecialtyQuery;
                        while($row = $results->fetch_array())
                        {
                            //echo "<tr>";
                            // echo "<td class='rowID'>". $row["app_id"] . "</td>";
                            echo "<option>" . $row["Specialty"] .  "</option>";
                            //echo "<td>". $row["CompletedDate"] . "</td>";
                            //echo "<td> <a style='text-decoration: none; color: red;' href='mailto:". $row["EMail1"] . "'/a>". $row["EMail1"]."</td>";
                            //echo "<td style='border-bottom: none;'><a class ='viewButton' href='app.php?record=". $row["app_id"] . "' target='viewer'>View</a></td>";
                            //echo "</tr>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="sel2">Course:</label>
                    <select multiple class="form-control" id="sel2">
                        <?php
                        $pCourseQuery = "SELECT * FROM Primary_Courses ORDER BY Course ASC";
                        $results = $dbc->query($pCourseQuery);
                        echo $pCourseQuery;
                        while($row = $results->fetch_array())
                        {
                            //echo "<tr>";
                            // echo "<td class='rowID'>". $row["app_id"] . "</td>";
                            echo "<option>" . $row["Course"] .  "</option>";
                            //echo "<td>". $row["CompletedDate"] . "</td>";
                            //echo "<td> <a style='text-decoration: none; color: red;' href='mailto:". $row["EMail1"] . "'/a>". $row["EMail1"]."</td>";
                            //echo "<td style='border-bottom: none;'><a class ='viewButton' href='app.php?record=". $row["app_id"] . "' target='viewer'>View</a></td>";
                            //echo "</tr>";
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="panel-heading">
            More assignment details:
        </div>

        <div class ="panel-body" id="txtTitle">

            <div class="col-sm-4">
                <div class="form-group">
                    <label for="title">Title:</label>
                    <textarea class="form-control" id="title" placeholder="Enter Text..."></textarea>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label for="comments">Comments:</label>
                    <textarea class="form-control" id="comments" placeholder="Enter Text..."></textarea>
                </div>
            </div>

            <div class="col-sm-4">
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" placeholder="Enter Text..."></textarea>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="checkbox text-center">
                <label><input type="checkbox"> Willing to grade the assignment?</label>
            </div>

            <div class="checkbox text-center">
                <label><input type="checkbox"> Is a rubric included with the assignment?</label>
            </div>
        </div>

        <div class="panel-heading">
            Upload your assignment:
        </div>
        <div class="panel-body">

            <form action="fileUploader.php" method="post" enctype="multipart/form-data">
                <div class="form-group text-center">
                Browse to the zip file you want to upload:

                    <div class="container">
                    <div class="row">
                    <span class="btn btn-default btn-file">
                        Browse <input type="file" name="fileToUpload" id="fileToUpload">
                    </span>

                    <span class="btn btn-default btn-file">
                        Upload <input type="submit" value="Upload Zip" name="submit">
                    </span>
                    </div>

                </div>
            </form>

        </div>
    </div>
</div>
</html>
