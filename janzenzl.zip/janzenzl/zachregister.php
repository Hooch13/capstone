<?php
require('library.php');
?>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/simple-sidebar.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/custom.css">
<div class="container jumbotron h2 text-center">Register</div>
<div class="container">
<form role="form" action="zachregister.php" method="post">
    <div class="form-group">
        <label for="FirstName">First Name:</label>
        <input type="text" class="form-control" id="FirstName" name="FirstName">
    </div>
    <div class="form-group">
        <label for="LastName">Last Name:</label>
        <input type="text" class="form-control" id="LastName" name="LastName">
    </div>
    <div class="form-group">
        <label for="Email">Email address:</label>
        <input type="email" class="form-control" id="Email" name="Email">
    </div>
    <div class="form-group">
        <label for="Password">Password:</label>
        <input type="password" class="form-control" id="Password" name="Password">
    </div>
    <div class="form-group">
        <label>Choose a security question:</label>
        <select name="SecurityQuestionID">
            <option value="1">What was the name of your first pet?</option>
            <option value="3">What was the name of your last pet?</option>
            <option value="4">What was the mascot of your High School?</option>
            <option value="5">Who was your favorite teacher in High School?</option>
        </select>
    </div>
    <div class="form-group">
        <label for="SecurityQuestionAnswer">Security Question Answer:</label>
        <input type="text" class="form-control" id="SecurityQuestionAnswer" name="SecurityQuestionAnswer">
    </div>

    <input type='hidden' name='submit' />
    <input type="submit" value="register" />

</form>
    </div>

<?php
if(isset($_POST['submit'])) {
    $user = new User();
    $user->FirstName = $_POST["FirstName"];
    $user->LastName = $_POST["LastName"];
    $user->Email = $_POST["Email"];
    $user->Password = CreateSecurePassword($_POST["Password"]);
    $user->SecurityQuestionID = $_POST["SecurityQuestionID"];
    $user->SecurityQuestionAnswer = $_POST["SecurityQuestionAnswer"];
    $user->UserRankID = 3;
try{
    CreateUser($user, $dbc);
    echo "<div class='container alert alert-success text-center'>Thank you for registering!</div>";
}
catch (Exception $e){
    echo "<div class='container alert alert-danger text-center'>Caught exception: ", $e->getMessage(), "</div>";
}

    $dbc->close();
}
?>