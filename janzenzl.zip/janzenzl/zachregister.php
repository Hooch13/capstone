<?php

require('library.php');

$user = new User();
$user->FirstName = 'Bill';
$user->LastName = 'Nicholson';
$user->Email = 'nicholdw@ucmail.uc.edu';
$user->Password = CreateSecurePassword('test1234');
$user->SecurityQuestionID = 1;
$user->SecurityQuestionAnswer = 'bike';
$user->UserRankID = 1;

CreateUser($user, $dbc);

$dbc->close();

?>