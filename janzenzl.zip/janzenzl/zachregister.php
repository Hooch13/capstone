<?php
require('library.php');

$passwordInvalid = false; // Assume password is valid
$emailDuplicate = false; // Assume email is unique
$questionInvalid = false; // Assume question not hacked

if(isset($_POST['submit'])) {
    $user = new User();
    $user->FirstName = $_POST["FirstName"];
    $user->LastName = $_POST["LastName"];
    $user->Email = $_POST["Email"];
    $user->Password = CreateSecurePassword($_POST["Password"]);
    $user->SecurityQuestionID = $_POST["SecurityQuestionID"];
    $user->SecurityQuestionAnswer = $_POST["SecurityQuestionAnswer"];
    $user->UserRankID = 3;

    if(strlen($_POST["Password"]) < 8 || strlen($_POST["Password"]) > 30) { // Invalid password
        $passwordInvalid = true;
    }
    else if(!SecurityQuestionIDIsValid($user->SecurityQuestionID, $dbc)) {
        $questionInvalid = true;
    }
    else if(CreateUser($user, $dbc) === 0) { // Success
            // Redirect to login
            header("Location: login.php?register=successful");
            exit();
        }
    else {
        $emailDuplicate = true;
    }
}
?>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/simple-sidebar.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/custom.css">
<div class="container jumbotron h2 text-center">Register</div>
<div class="container">
<form role="form" action="zachregister.php" method="post">
    <div class="form-group">
        <label for="FirstName">First Name:</label>
        <input type="text" class="form-control" id="FirstName" name="FirstName">
    </div>
    <div class="form-group">
        <label for="LastName">Last Name:</label>
        <input type="text" class="form-control" id="LastName" name="LastName">
    </div>
    <div class="form-group">
        <?php
        if($emailDuplicate)
            echo '<label class="alert alert-danger">Email already exists.</label><br>';
        ?>
        <label for="Email">Email address:</label>
        <input type="email" class="form-control" id="Email" name="Email">
    </div>
    <div class="form-group">
        <?php
            if($passwordInvalid)
                echo '<label class="alert alert-danger">Password must be between 8 and 30 characters.</label><br>';
        ?>
        <label for="Password">Password:</label>
        <input type="password" class="form-control" id="Password" name="Password">
    </div>
    <div class="form-group">
        <?php
            if($questionInvalid)
                echo '<label class="alert alert-danger">Secuity question index was changed in the source code.</label><br>';
        ?>
        <label>Choose a security question:</label>
        <select name="SecurityQuestionID">
            <?php
            $SecurityQuestionQuery = "SELECT * FROM tSecurityQuestion ORDER BY SecurityQuestion ASC";
            $results = $dbc->query($SecurityQuestionQuery);
            echo $SecurityQuestionQuery;
            while($row = $results->fetch_array())
            {
                echo "<option value='" .$row[SecurityQuestionID] . "'>". $row["SecurityQuestion"] .  "</option>";
            }
            ?>
        </select>
    </div>
    <div class="form-group">
        <label for="SecurityQuestionAnswer">Security Question Answer:</label>
        <input type="text" class="form-control" id="SecurityQuestionAnswer" name="SecurityQuestionAnswer">
    </div>

    <input type='hidden' name='submit' />
    <input type="submit" value="register" />

</form>
    </div>

<?php
$dbc->close();
?>