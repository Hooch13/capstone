<?php
require ('db_connect.php');
// a data entity class
class User
{
    public $FirstName;
    public $LastName;
    public $Email;
    public $Bio;
    public $Password;
    public $OfficeHours;
    public $RoomNum;
    public $Phone;
    public $PreferredContactMethod;
    public $SecurityQuestionID;
    public $SecurityQuestionAnswer;
    public $LastLoginTime;    
    public $FailedLoginAttempts;
    public $UserRankID;
}


    function CreateUser($user, $dbc)
    {

// want to write a query that inserts the user properties into the tUser table.
        $stmt = $dbc->prepare
        ("INSERT INTO tUser(FirstName, LastName, Email, Bio, Password, OfficeHours, RoomNum, Phone, PreferredContactMethod, SecurityQuestionID, SecurityQuestionAnswer, LastLoginTime, FailedLoginAttempts, UserRankID)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        //var_dump($stmt);
        echo '<br>';
        var_dump($user);
        $stmt->bind_param('ssssssssssssss', $firstName, $lastName, $email, $bio, $password, $officeHours, $roomNum, $phone, $preferredContactMethod, $securityQuestionID, $securityQuestionAnswer, $lastLoginTime, $failedLoginAttempts, $userRankID);
        $firstName = $user->FirstName;
        $lastName = $user->LastName;
        $email = $user->Email;
        $bio = $user->Bio;
        $password = $user->Password;
        $officeHours = $user->OfficeHours;
        $roomNum = $user->RoomNum;
        $phone = $user->Phone;
        $preferredContactMethod = $user->PreferredContactMethod;
        $securityQuestionID = $user->SecurityQuestionID;
        $securityQuestionAnswer = $user->SecurityQuestionAnswer;
        $lastLoginTime = $user->LastLoginTime;
        $failedLoginAttempts = $user->FailedLoginAttempts;
        $userRankID = $user->UserRankID;

            $stmt->execute();

    }



function CreateSecurePassword($password)
{
    $encryptedPassword = md5($password);
    return $encryptedPassword;
}
?>