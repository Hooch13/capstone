<?PHP
include("loginCheck.php");
include("nav.php");
 // end session login
?>

<div class="row">
	<div class="container">
		<div class="h2 text-center col-lg-9">
			Results:
		</div>
	</div>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-6 h4 jumbotron" id="myListChanges">

				<ul>
					<li><a href="#"> nursing and IT </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>
					<li><a href="#"> A listed assignment </a></li>

				</ul>

		</div>
		<!--/span-->
		<div class="col-md-3">
			<div class="sidebar-nav-fixed pull-right affix" id="mySidebarSearchResults">
				<div class="well">
					<ul class="nav">

						<li class="nav-header h4">Uploader Information</li>
						<li class="list-group-item"> Susan B. Anthony
						</li>

						<li class="nav-header h4">Assignment Name</li>
						<li class="list-group-item"> Racial Descrimination
						</li>

						<li class="nav-header h4">Assignment Description</li>
						<li class="list-group-item"> This assignment talks about how Susan B. Anthony effected
							peoples' view on racism
						</li>

						<li class="nav-header h4">Subject</li>
						<li class="list-group-item"> Humanity
						</li>

						<li class="nav-header h4">Specialty</li>
						<li class="list-group-item"> Stereotypes
						</li>

						<li class="nav-header h4">Course</li>
						<li class="list-group-item"> PSY1001
						</li>

						<li class="nav-header h4">Focus Subject</li>
						<li class="list-group-item"> Psychology
						</li>

						<li class="nav-header h4">Focus Specialty</li>
						<li class="list-group-item"> Psychological effects
						</li>

						<li class="nav-header h4">Focus Course</li>
						<li class="list-group-item"> PHI2003
						</li>

						<li class="nav-header h4">Willing to Grade?</li>
						<li class="list-group-item"> No
						</li>

					</ul>
				</div>
				<!--/.well -->
			</div>
			<!--/sidebar-nav-fixed -->
		</div>
		<!--/span-->
	</div>
	<!--/row-->

</div>
<!--/.fluid-container-->


