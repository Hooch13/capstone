<?php session_start();

// STEP 2. Check if a user is logged in by checking the session value
if($_SESSION['logged_in']==true){
 
    // if it is, redirect to index page and tell the user he's already logged in
	 ?>
		   <META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://masterzcreations.com/college/capstone/index.php?action=already_logged_in">
		   <?PHP
    
}
?>
<html>
    <head>
        <title>File Manager</title>
        <!--<link type="text/css" rel="stylesheet" href="style.css" />-->
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/simple-sidebar.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/custom.css">
    </head>
<body>
 
<div id="loginForm"> 
 
    <?php
    // STEP 3. Check for an action and show the approprite message.
    if($_GET['action']=='not_yet_logged_in'){
        echo "<div class='container'><div class='alert alert-warning'>Please Login below.</div></div>";
    }
     
    // STEP 4. Check if the user clicked the 'Login' button already by checking the PHP $_POST variable
    if($_POST){
         
        // these username and password are just examples, it should be from you database
        // passwords must be encrypted (salt and hash) to be secured, this post should give you an idea or see the update below
        $username = 'admin';
        $password = 'admin';
         
        // check if the inputted username and password match
        if(($_POST['username']==$username) && ($_POST['password']==$password)){
             
            // if it is, set the session value to true
            $_SESSION['logged_in'] = true;
             
            // and redirect to your site's admin or index page
           ?>
            <META HTTP-EQUIV="Refresh" CONTENT="0; URL=http://masterzcreations.com/college/capstone/index.php">		   <?PHP
             
        }else{
         
            // if it does not match, tell the user his access is denied.
            echo "<div class='container'><div class='alert alert-danger'>Access denied. </div></div>";
        }
    }
    ?>
 
    <!-- where the user will enter his username and password
    <form action="login.php" method="post" class="form-horizontal" role="form">




        <div id="formBody">
            <div class="formField">
                <input type="text" name="username" placeholder="Username" />
            </div>

            <div class="formField">
                <input type="password" name="password" placeholder="Password" />
            </div>

            <div>
                <input type="submit" value="Login" class="customButton" />
            </div>
        </div>

    </form action="login.php" method="post" class="form-horizontal" role="form">
    <!------------------------------------------------ -->

    <form action="login.php" method="post" class="form-horizontal" role="form">

        <div class="container">
            <div class="jumbotron h1 text-center"">Login</div>

        <div class="container center_div">
        <div class="row">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" class="form-control" name="username">
        </div>
        </div>

        <div class="row">
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control" name="password">
        </div>
        </div>

        <div class="row">
        <div class="checkbox">
            <label><input type="checkbox"> Remember me</label>
        </div>
            <a href="zachregister.php">Need to register for an account?</a>
        </div>

        <div class="row">
        <input type="submit" value="Login" class="btn btn-default" />
        </div>
            </div>
    </form action="login.php" method="post" class="form-horizontal" role="form">
     
    </div>

</body>
</html>