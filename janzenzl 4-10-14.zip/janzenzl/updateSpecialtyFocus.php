<?php session_start();

include ("loginCheck.php");

include ("nav.php");

include ("db_connect.php");

$specialtyF = $_POST['txtSpecialtyFocusAdd'];
//('".$_POST['txtSpecialtyFocusAdd']."')
$AddStatement = "INSERT INTO tSpecialty (Specialty) VALUES ('$specialtyF')";

if(!empty($specialtyF)){
    $inserted = mysqli_query($dbc, $AddStatement);
}



?>

<div class="form-group" id="focusSpecialtyAdd">
    <label for="specialtyFocus">Specialty:</label>
    <select multiple class="form-control" id="specialty" name="specialtyFocus[]">
        <?php
        $pSpecialtyQuery = "SELECT * FROM tSpecialty ORDER BY Specialty ASC";
        $results = $dbc->query($pSpecialtyQuery);
        echo $pSpecialtyQuery;

        while ($row = $results->fetch_array())
        {
            echo "<option value='" . $row["SpecialtyID"] . "'>" . $row["Specialty"] . "</option>";
        }

        ?>
    </select>
</div>
