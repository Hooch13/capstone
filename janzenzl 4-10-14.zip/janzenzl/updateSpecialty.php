<?php session_start();

include ("loginCheck.php");

include ("nav.php");

include ("db_connect.php");

//bavotasan.com/2009/processing-multiple-forms-on-one-page-with-php/
$specialty = $_POST['txtSpecialtyAdd'];
//('".$_POST['txtSpecialtyAdd']."')
$AddStatement = "INSERT INTO tSpecialty (Specialty) VALUES ('$specialty')";

if(!empty($specialty)){
    $inserted = mysqli_query($dbc, $AddStatement);
}








?>

<div class="form-group" id="specialtyDivInner">
    <label for="specialty">Specialty:</label>
    <select multiple class="form-control" id="specialty" name="specialty[]">
        <?php
        $pSpecialtyQuery = "SELECT * FROM tSpecialty ORDER BY Specialty ASC";
        $results = $dbc->query($pSpecialtyQuery);
        echo $pSpecialtyQuery;

        while ($row = $results->fetch_array())
        {
            echo "<option value='" . $row["SpecialtyID"] . "'>" . $row["Specialty"] . "</option>";
        }

        ?>
    </select>
</div>
