<?PHP
session_start();
include("loginCheck.php");
include("ryan_library.php");
include("nav.php");
$assignmentPath = "assignments/"; // if the folder where storing all the assignments is changed, you change it here.
 // end session login
?>


<!-- Start content if Log in is successful -->
<html>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="bootstrap/css/dashboard.css">
<style>
.rTable { display: table; width: 100%;} 
.rTableRow { display: table-row; }
.rTableHeading { background-color: #ddd; display: table-header-group; }
.rTableCell, .rTableHead { display: table-cell; padding: 2px 5px; border: 1px solid #999999; }
.rTableHeading { display: table-header-group; background-color: #ddd; font-weight: bold; }
.rTableFoot { display: table-footer-group; font-weight: bold; background-color: #ddd; }
.rTableBody { display: table-row-group; } 
</style>
<body>
	<div class="container">
		<div class="jumbotron h1 text-center">
			Dashboard
			<!--JUMBO--></div>
			<div id="content">
			<p>Newest In All Departments</p>
			<!-- <div id="Newest"> -->
				<div class="rTable">
					<div class="rTableBody">
						<div class="rTableRow">
							<h3 class="rTableCell">Download File</h3>
							<h3 class="rTableCell">Title</h3>
							<h3 class="rTableCell">Description</h3>
							<!--<h3 class="rTableHeading">Subject</h3> -->
							<h3 class="rTableCell">Will Be Graded</h3>
							<h3 class="rTableCell">Rubric Included</h3>
						</div>
						<?PHP $qLatestAssigments = "SELECT * FROM tAssignment ORDER BY DateTimeUploaded DESC limit 25";  
								$LatestAssigmentsResults = $dbc->query($qLatestAssigments);
								//echo $qLatestAssigments;
								while($row = $LatestAssigmentsResults->fetch_array())
								{
									if(strcmp($row['WillBeGraded'],"Y") ==0){$WBG = "Yes";} else{$WBG = "No";}
									if(strcmp($row['RubricIncluded'],"Y") ==0){$RI = "Yes";} else{$RI = "No";}
									echo '<div class="rTableRow">';
										$downloadURL = $assignmentPath . $row['UserID'] .'/'. $row['File'];
										
										echo '<div class="rTableCell"><a href="'.$assignmentPath . $row['UserID'] .'/'. $row['File']. '"><span class="glyphicon glyphicon-download"></span></a></div>';
										echo '<div class="rTableCell">'. $row['Title'] .'</div>';
										echo '<div class="rTableCell">'. $row['Description'] .'</div>';
									// echo '<div class="rTableCell">'. $row['Subject'] .'</div>';
										echo '<div class="rTableCell">'. $WBG .'</div>';
										echo '<div class="rTableCell">'. $RI .'</div>';
									echo '</div>';
								}
								
								?>
								
						</div>
					</div> <!-- End of table -->
				<!--</div> <!-- End of Newest -->
			
			<br />
			<p>Recent Uploaded By Department</p>
<!--			<div id="RecentU">-->
				<div class="rTable">
					<div class="rTableBody">
						<div class="rTableRow">
							<h3 class="rTableCell">Download File</h3>
							<h3 class="rTableCell">Title</h3>
							<h3 class="rTableCell">Description</h3>
							<!--<h3 class="rTableCell">Subject</h3> -->
							<h3 class="rTableCell">Will Be Graded</h3>
							<h3 class="rTableCell">Rubric Included</h3>
						</div>
						<?PHP $qLatestAssigments = "SELECT * FROM tAssignment ORDER BY DateTimeUploaded DESC limit 25";  
								$LatestAssigmentsResults = $dbc->query($qLatestAssigments);
								//echo $qLatestAssigments;
								while($row = $LatestAssigmentsResults->fetch_array())
								{
									if(strcmp($row['WillBeGraded'],"Y") ==0){$WBG = "Yes";} else{$WBG = "No";}
									if(strcmp($row['RubricIncluded'],"Y") ==0){$RI = "Yes";} else{$RI = "No";}
									echo '<div class="rTableRow">';
										echo '<div class="rTableCell"><a href="'.$assignmentPath . $row['UserID'] .'/'. $row['File']. '"><span class="glyphicon glyphicon-download"></span></a></div>';
										echo '<div class="rTableCell">'. $row['Title'] .'</div>';
										echo '<div class="rTableCell">'. $row['Description'] .'</div>';
									// echo '<div class="rTableCell">'. $row['Subject'] .'</div>';
										echo '<div class="rTableCell">'. $WBG .'</div>';
										echo '<div class="rTableCell">'. $RI .'</div>';
									echo '</div>';
								}
								
								?>
								
						</div>
					</div> <!-- End of table -->
			</div>


			<br />
			<!--<p>Recent Downloaded</p>
			<div id="RecentD">
	  
			</div> --> 
		</div><!-- End of C