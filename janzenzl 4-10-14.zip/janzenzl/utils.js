

<!-- ---------------------Add SUBJECT DB----------------------- -->
    $(document).ready(function() {
    $("#btnAddSubject").click(function () {
      var msg = $('#txtSubjectAdd').val();


      $.ajax({
         type : "POST",
         url : "updateSubject.php",
         data : "txtSubjectAdd=" + msg




      });
      alert("Subject Added");
      $('#subjectDivInner').load('updateSubject.php #subjectDivInner').fadeOut().fadeIn("fast");

      document.getElementById('txtSubjectAdd').value = "";

   });
});


<!-- ---------------------Add SPECIALTY DB----------------------- -->


$(document).ready(function() {
   $("#btnAddSpecialty").click(function () {
      var msg = $('#txtSpecialtyAdd').val();
      //alert(msg+" Was here");

      $.ajax({
         type : "POST",
         url : "updateSpecialty.php",
         data : "txtSpecialtyAdd=" + msg
      });
      alert("Specialty Added");
      $('#specialtyDivInner').load('updateSpecialty.php #specialtyDivInner').fadeOut().fadeIn("fast");
      document.getElementById('txtSpecialtyAdd').value = "";
   });
});

   <!-- ---------------------Add COURSE DB----------------------- -->

$(document).ready(function() {
   $("#btnAddCourse").click(function () {
      var msg = $('#txtCourseAdd').val();


      $.ajax({
         type : "POST",
         url : "updateCourse.php",
         data : "txtCourseAdd=" + msg
      });

      alert("Course Added");
      $('#courseDivInner').load('updateCourse.php #courseDivInner').fadeOut().fadeIn("fast");
      document.getElementById('txtCourseAdd').value = "";
   });
});


   <!-- ---------------------Add SUBJECTFOCUS DB----------------------- -->

$(document).ready(function() {
   $("#btnAddSubjectFocus").click(function () {
      var msg = $('#txtSubjectFocusAdd').val();
      //alert(msg+" Was here");

      $.ajax({
         type : "POST",
         url : "updateSubjectFocus.php",
         data : "txtSubjectFocusAdd=" + msg
      });

      alert("Subject Focus Added");
      $('#focusSubjectAdd').load('updateSubjectFocus.php #focusSubjectAdd').fadeOut().fadeIn("fast");
      document.getElementById('txtSubjectFocusAdd').value = "";
   });
});


   <!-- ---------------------Add SPECIALTYFOCUS DB----------------------- -->

$(document).ready(function() {
   $("#btnAddSpecialtyFocus").click(function () {
      var msg = $('#txtSpecialtyFocusAdd').val();
      //alert(msg+" Was here");

      $.ajax({
         type : "POST",
         url : "updateSpecialtyFocus.php",
         data : "txtSpecialtyFocusAdd=" + msg
      });

      alert("Specialty Focus Added");
      $('#focusSpecialtyAdd').load('updateSpecialtyFocus.php #focusSpecialtyAdd').fadeOut().fadeIn("fast");
      document.getElementById('txtSpecialtyFocusAdd').value = "";
   });
});



   <!-- ---------------------Add COURSEFOCUS DB----------------------- -->

$(document).ready(function() {
   $("#btnAddCourseFocus").click(function () {
      var msg = $('#txtCourseFocusAdd').val();
      //alert(msg+" Was here");

      $.ajax({
         type : "POST",
         url : "updateCourseFocus.php",
         data : "txtCourseFocusAdd=" + msg
      });

      alert("Course Focus Added");
      $('#focusCourseAdd').load('updateCourseFocus.php #focusCourseAdd').fadeOut().fadeIn("fast");
      document.getElementById('txtCourseFocusAdd').value = "";
   });
});


