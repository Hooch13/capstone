<?php session_start();

include ("loginCheck.php");

include ("nav.php");

include ("db_connect.php");

$subjectF= $_POST['txtSubjectFocusAdd'];
//('".$_POST['txtSubjectFocusAdd']."')
$AddStatement = "INSERT INTO tSubject (Subject) VALUES ('$subjectF')";

if(!empty($subjectF)){

    $inserted = mysqli_query($dbc, $AddStatement);

}




?>

<div class="form-group" id="focusSubjectAdd">
    <label for="subjectFocus">Subject:</label>
    <select multiple class="form-control" id="subject" name="subjectFocus[]" >
        <?php
        $pSubjectQuery = "SELECT * FROM tSubject ORDER BY Subject ASC";
        $results = $dbc->query($pSubjectQuery);
        echo $pSubjectQuery;

        while ($row = $results->fetch_array())
        {
            echo "<option value='" . $row["SubjectID"] . "'>" . $row["Subject"] . "</option>";
        }

        ?>

    </select>
</div>
