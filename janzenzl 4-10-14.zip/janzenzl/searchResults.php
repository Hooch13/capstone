<?PHP
include("loginCheck.php");
include("nav.php");
include("library.php");
// end session login


//print_r($_POST);
//print_r($_FILES);

$subject = $_POST['subject'];
$subjectFocus = $_POST['subjectFocus'];
$course = $_POST['course'];
$courseFocus = $_POST['courseFocus'];
$specialty = $_POST['specialty'];
$specialtyFocus = $_POST['specialtyFocus'];


$title = cleaning($_POST['title']);
$comments = cleaning($_POST['comments']);
$description = cleaning($_POST['description']);
$gradeAssignment = $_POST['gradeAssignment'];
$rubricAvailable = $_POST['rubricAvailable'];
$fileName = cleaning($_FILES["fileToUpload"]["name"]);

//search query every time they select something from the previous page needs to be searched...
$searchQuery = "SELECT * FROM tAssignment WHERE 1";

if ((strlen($title)) > 0) {
    $searchQuery .= " AND Title LIKE '%$title%'";
}
if ((strlen($comments) > 0)) {
    $searchQuery .= " AND Comments LIKE '%$comments%'";
}
if ((strlen($description) > 0)) {
    $searchQuery .= " AND Description LIKE '%$description%'";
}
if ($gradeAssignment === "on") {
    $searchQuery .= " AND WillBeGraded = 'Y'";
}
if ($rubricAvailable === "on") {
    $searchQuery .= " AND RubricIncluded = 'Y'";
}
if (count($subject) > 0) {
    $tmpString = implode(",", $subject);
    $searchQuery .= " AND AssignmentID IN (SELECT AssignmentID FROM tAssignment_IntermediateSSC WHERE SubjectID IN ($tmpString))";
}
if (count($specialty) > 0) {
    $tmpString = implode(",", $specialty);
    $searchQuery .= " AND AssignmentID IN (SELECT AssignmentID FROM tAssignment_IntermediateSSC WHERE SpecialtyID IN ($tmpString))";
}
if (count($course) > 0) {
    $tmpString = implode(",", $course);
    $searchQuery .= " AND AssignmentID IN (SELECT AssignmentID FROM tAssignment_IntermediateSSC WHERE CourseID IN ($tmpString))";
}
if (count($subjectFocus) > 0) {
    $tmpString = implode(",", $subjectFocus);
    $searchQuery .= " AND AssignmentID IN (SELECT AssignmentID FROM tAssignment_IntermediateSSC WHERE FocusSubjectID IN ($tmpString))";
}
if (count($specialtyFocus) > 0) {
    $tmpString = implode(",", $specialtyFocus);
    $searchQuery .= " AND AssignmentID IN (SELECT AssignmentID FROM tAssignment_IntermediateSSC WHERE FocusSpecialtyID IN ($tmpString))";
}
if (count($courseFocus) > 0) {
    $tmpString = implode(",", $courseFocus);
    $searchQuery .= " AND AssignmentID IN (SELECT AssignmentID FROM tAssignment_IntermediateSSC WHERE FocusCourseID IN ($tmpString))";
}

$searchQuery .= " GROUP BY AssignmentID";
echo $searchQuery;
$_SESSION["searchQuery"] = $searchQuery;


?>


<div class="row">
    <div class="container">
        <div class="h2 text-center jumbotron">
            Results:
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div id="zachRegForm">
            <div class="col-md-6 h4" id="myListChanges">
                <ul id="searchResultList">
                    <?php
                    $results = $dbc->query($searchQuery);
                    //echo $searchQuery;
                    while ($row = $results->fetch_array()) {
                        $buildURL = 'searchResultsSideBar.php?rid=' . $row['AssignmentID'];
                        echo "<li><a href=" . $buildURL . " target='searchResultsSideBar'>" . $row["Title"] . "</li>";


                    }

                    ?>
                </ul>
            </div>
            <!--/span-->
            <object width="400" height="100%" data="searchResultsSideBar.php" name="searchResultsSideBar"></object>
            <!--/span-->
        </div>
    </div>
    <!--/row-->

</div>
<!--/.fluid-container-->


