<?PHP session_start();


?>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/custom.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>



<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="dashboard.php">Navigation</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li><a href="dashboard.php"><span class="glyphicon glyphicon-home"></span> Dashboard</a></li>
                <li><a href="profile.php"><span class="glyphicon glyphicon-user"></span> Profile</a></li>
                <li><a href="upload.php"><span class="glyphicon glyphicon-upload"></span> Upload</a></li>
                <li><a href="search.php"><span class="glyphicon glyphicon-search"></span> Search</a></li>
                <?PHP
                $level = $_SESSION['UserRank'];
                if ($level == 1) {
                    ?>
                    <li>
                        <a href="admin_new.php"><span class="glyphicon glyphicon-star"></span> Admin</a>
                    </li>
                <?PHP }?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="index.php?action=logout"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
<!--                <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>-->
            </ul>
        </div>
    </div>
</nav>



