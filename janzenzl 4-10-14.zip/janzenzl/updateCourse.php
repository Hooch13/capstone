<?php session_start();

include ("loginCheck.php");

include ("nav.php");

include ("db_connect.php");

$course = $_POST['txtCourseAdd'];

//('".$_POST['txtCourseAdd']."')


$AddStatement = "INSERT INTO tCourse (Course) VALUES ('$course')";

if(!empty($course)){
    $inserted = mysqli_query($dbc, $AddStatement);

}
?>

<div class="form-group" id="courseDivInner">
    <label for="course">Course:</label>
    <select multiple class="form-control" id="course" name="course[]">
        <?php
        $pCourseQuery = "SELECT * FROM tCourse ORDER BY Course ASC";
        $results = $dbc->query($pCourseQuery);
        echo $pCourseQuery;

        while ($row = $results->fetch_array())
        {
            echo "<option value='" . $row["CourseID"] . "'>" . $row["Course"] . "</option>";
        }

        ?>
    </select>
</div>
