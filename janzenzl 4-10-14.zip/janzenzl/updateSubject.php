<?php session_start();

include ("loginCheck.php");

include ("nav.php");

include ("db_connect.php");


//('".$_POST['txtSubjectAdd']."')"
$subject = $_POST['txtSubjectAdd'];
$AddStatement = "INSERT INTO tSubject (Subject) VALUES ('$subject')";

if(!empty($subject)){
 //$results = $dbc->query($AddStatement);
 $inserted = mysqli_query($dbc, $AddStatement);
}


// ----- Div to be loaded into old Div on updatePage -----
?>

<div class="form-group" id="subjectDivInner">
 <label for="subject">Subject:</label>
 <select multiple class="form-control" id="subject" name="subject[]" >
  <?php
  $pSubjectQuery = "SELECT * FROM tSubject ORDER BY Subject ASC";
  $results = $dbc->query($pSubjectQuery);
  //echo $pSubjectQuery;

  while ($row = $results->fetch_array())
  {
   echo "<option value='" . $row["SubjectID"] . "'>" . $row["Subject"] . "</option>";

  }

  ?>

 </select>
</div id="SubjectAddDiv">
<!----- Div to be loaded into old Div on updatePage ----->