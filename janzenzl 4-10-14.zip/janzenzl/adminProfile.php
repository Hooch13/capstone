<?PHP include("library.php");

$assignmentPath = "assignments/";
?>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/simple-sidebar.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/custom.css">
<?PHP
    $userID = $_GET["uid"];
    if(!isset($userID)){ $userID = 0;}
    /* SELECT column_name(s)
    FROM table1
    JOIN table2
    ON table1.column_name=table2.column_name;*/
    $profileQuery = "SELECT * FROM tUser, tUserRank
	  WHERE tUser.UserRankID = tUserRank.UserRankID
	  AND tUser.UserID = ". $userID;
    echo $profileQuery;
$results = $dbc->query($profileQuery);
if($results) {
    while ($row = $results->fetch_array()) {
?>
        <div>
            <div class="sidebar-nav-fixed pull-right affix" id="myAdminProfile">
                <div class="well">
                    <ul class="nav">
                        <li class="nav-header h5">First Name</li>
                        <li class="list-group-item"> <?PHP echo $row["FirstName"]; ?>
                        </li>

                        <li class="nav-header h5">Last Name</li>
                        <li class="list-group-item"><?PHP echo $row["LastName"]; ?>
                        </li>

                        <li class="nav-header h5">Rank</li>
                        <li class="list-group-item"><?PHP echo $row["UserRankName"]; ?>
                        </li>
                    </ul>
                </div>
                <!--/.well -->
            </div>
            <!--/sidebar-nav-fixed -->
        </div>

    <?PHP }
}

?>