-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2016 at 03:08 PM
-- Server version: 5.5.42-37.1
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mzc_group3`
--

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment`
--

CREATE TABLE IF NOT EXISTS `tAssignment` (
  `AssignmentID` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Comments` text,
  `File` text NOT NULL,
  `WillBeGraded` char(1) NOT NULL DEFAULT 'N',
  `RubricIncluded` char(1) NOT NULL DEFAULT 'N',
  `DateTimeUploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tAssignment`
--

INSERT INTO `tAssignment` (`AssignmentID`, `Title`, `Description`, `Comments`, `File`, `WillBeGraded`, `RubricIncluded`, `DateTimeUploaded`, `UserID`) VALUES
(86, 't', 'c', 'd', 'TestFile.zip', 'N', 'N', '2016-04-05 20:06:01', 56),
(87, '1', '111', '11', 'TestFile - Copy (2).zip', 'Y', 'N', '2016-04-05 20:10:06', 56),
(88, 't', 'c', 'd', 'TestFile - Copy (4).zip', 'Y', 'Y', '2016-04-05 20:17:31', 56),
(89, 't', 'c', 'd', 'TestFile - Copy (5).zip', 'Y', 'Y', '2016-04-05 20:19:33', 56),
(90, 't', 'c', 'd', 'TestFile - Copy (6).zip', 'Y', 'Y', '2016-04-05 20:31:38', 56),
(91, '', '', '', 'TestFile - Copy (7).zip', 'Y', 'Y', '2016-04-05 20:33:30', 56),
(92, '', '', '', 'TestFile - Copy (8).zip', 'N', 'Y', '2016-04-06 02:49:10', 56),
(93, 'd', 'd', 'd', 'TestFile.zip', 'Y', 'Y', '2016-04-06 02:51:19', 56),
(94, '', '', '', 'TestFile - Copy (5).zip', 'N', 'N', '2016-04-06 03:29:18', 56),
(95, 'Fuck', 'TEST', 'AJAX', 'TestFile - Copy (7).zip', 'N', 'N', '2016-04-06 03:30:47', 56),
(96, 'HERE IT IS', '', '', 'TestFile.zip', 'Y', 'Y', '2016-04-08 10:05:27', 56),
(97, 'IT Basics', 'This is an tntro to computer''s lesson.', 'None', 'problem3_starter_files.zip', 'N', 'N', '2016-04-10 03:32:49', 75);

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_Course`
--

CREATE TABLE IF NOT EXISTS `tAssignment_Course` (
  `Assignment_CourseID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_IntermediateSSC`
--

CREATE TABLE IF NOT EXISTS `tAssignment_IntermediateSSC` (
  `Assignment_IntermediateSSCID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `SubjectID` int(11) DEFAULT NULL,
  `SpecialtyID` int(11) DEFAULT NULL,
  `CourseID` int(11) DEFAULT NULL,
  `FocusSubjectID` int(11) DEFAULT NULL,
  `FocusSpecialtyID` int(11) DEFAULT NULL,
  `FocusCourseID` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=297 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_Specialty`
--

CREATE TABLE IF NOT EXISTS `tAssignment_Specialty` (
  `Assignment_SpecialtyID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `SpecialtyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_Subject`
--

CREATE TABLE IF NOT EXISTS `tAssignment_Subject` (
  `Assignment_SubjectID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tAssignment_Subject`
--

INSERT INTO `tAssignment_Subject` (`Assignment_SubjectID`, `AssignmentID`, `SubjectID`) VALUES
(1, 10, 4),
(2, 11, 4),
(3, 12, 4),
(4, 13, 5),
(5, 14, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tCourse`
--

CREATE TABLE IF NOT EXISTS `tCourse` (
  `CourseID` int(11) NOT NULL,
  `Course` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tCourse`
--

INSERT INTO `tCourse` (`CourseID`, `Course`) VALUES
(1, 'ENG1001'),
(2, 'IT1020'),
(3, 'CHEM1001'),
(4, 'MATH1001');

-- --------------------------------------------------------

--
-- Table structure for table `tSecurityQuestion`
--

CREATE TABLE IF NOT EXISTS `tSecurityQuestion` (
  `SecurityQuestionID` int(11) NOT NULL,
  `SecurityQuestion` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tSecurityQuestion`
--

INSERT INTO `tSecurityQuestion` (`SecurityQuestionID`, `SecurityQuestion`) VALUES
(1, 'What was the name of your first pet?'),
(3, 'What was the name of your last pet?'),
(4, 'What was the mascot of your High School?'),
(5, 'Who was your favorite teacher in High School?'),
(6, 'What was your favorite place to vacation as a child?');

-- --------------------------------------------------------

--
-- Table structure for table `tSpecialty`
--

CREATE TABLE IF NOT EXISTS `tSpecialty` (
  `SpecialtyID` int(11) NOT NULL,
  `Specialty` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tSpecialty`
--

INSERT INTO `tSpecialty` (`SpecialtyID`, `Specialty`) VALUES
(1, 'Excel'),
(2, 'Charts'),
(4, 'Graphing'),
(5, 'Speaking'),
(6, 'Reading'),
(7, 'Writing'),
(8, 'Identifying');

-- --------------------------------------------------------

--
-- Table structure for table `tSubject`
--

CREATE TABLE IF NOT EXISTS `tSubject` (
  `SubjectID` int(11) NOT NULL,
  `Subject` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=312 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tSubject`
--

INSERT INTO `tSubject` (`SubjectID`, `Subject`) VALUES
(1, 'Information Technology'),
(2, 'Psychology'),
(3, 'Math'),
(4, 'Chemistry'),
(5, 'English'),
(24, 'Chess');

-- --------------------------------------------------------

--
-- Table structure for table `tUser`
--

CREATE TABLE IF NOT EXISTS `tUser` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `LastName` varchar(35) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Bio` tinyblob,
  `Password` varchar(100) NOT NULL,
  `OfficeHours` varchar(250) DEFAULT NULL,
  `RoomNum` varchar(25) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `PreferredContactMethod` varchar(25) DEFAULT NULL,
  `SecurityQuestionID` int(11) NOT NULL,
  `SecurityQuestionAnswer` varchar(250) NOT NULL,
  `LastLoginTime` datetime DEFAULT NULL,
  `FailedLoginAttempts` int(11) DEFAULT '0',
  `UserRankID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tUser`
--

INSERT INTO `tUser` (`UserID`, `FirstName`, `LastName`, `Email`, `Bio`, `Password`, `OfficeHours`, `RoomNum`, `Phone`, `PreferredContactMethod`, `SecurityQuestionID`, `SecurityQuestionAnswer`, `LastLoginTime`, `FailedLoginAttempts`, `UserRankID`) VALUES
(54, 'Ryan', 'Massey', 'testing@masterzcreations.com', NULL, 'afd5c7272ad94025e05e76c0aafef52d', NULL, NULL, NULL, NULL, 4, 'cougar', NULL, 0, 1),
(55, 'Jim', 'Richardson', 'jrich71@hotmail.com', NULL, '5f4dcc3b5aa765d61d8327deb882cf99', NULL, NULL, NULL, NULL, 4, 'trojan', NULL, 0, 1),
(56, 'Daryl', 'Wright', 'xer087@gmail.com', '', '5f4dcc3b5aa765d61d8327deb882cf99', '', '', '', '', 4, 'bulldog', NULL, 0, 1),
(57, 'Patrick', 'Voto', 'votopj@mail.uc.edu', NULL, 'bea6affdc6320d1cd6a525ae8df89a0d', NULL, NULL, NULL, NULL, 3, 'Skittles', NULL, 0, 1),
(58, 'John', 'Doe', 'john.doe@testing.com', NULL, 'afd5c7272ad94025e05e76c0aafef52d', NULL, NULL, NULL, NULL, 4, 'bearcats', NULL, 0, 2),
(59, 'Zach', 'Janzen', 'janzenzl@mail.uc.edu', NULL, '7989decd7c790bbd6304425a6d08db1e', NULL, NULL, NULL, NULL, 5, 'Doc Oc', NULL, 0, 1),
(63, 'test', 'mctester', 'testing@test.com', NULL, '7320d1035cb00f1e540bdbbb1d87ff69', NULL, NULL, NULL, NULL, 1, 'testpet', NULL, 0, 3),
(66, 'zach', 'test', 'zach@test.com', NULL, '9b7b5fa72edb352f6e5c71dae2cc0cd1', NULL, NULL, NULL, NULL, 4, 'e', NULL, NULL, 3),
(70, 'ben', 'ward', 'wardb3@mail.uc.edu', NULL, '5f4dcc3b5aa765d61d8327deb882cf99', NULL, NULL, NULL, NULL, 4, 'Rocket', NULL, NULL, 4),
(74, 'Ryan', 'Massey', 'massey@masterz.us', NULL, 'bb706fbadd80faca6f13889efc9b8310', NULL, NULL, NULL, NULL, 1, 'Smokey', NULL, NULL, 3),
(75, 'Ryan', 'Massey', 'masseyrc@mail.uc.edu', NULL, '4838d1e5c2004f9d575a9b674aab852f', NULL, NULL, NULL, NULL, 6, 'Myrtle Beach', NULL, NULL, 3),
(76, 'Ryan', 'Massey', 'massey@testing.com', 0x53747564656e74, 'bb706fbadd80faca6f13889efc9b8310', 'MWF 10-4', NULL, NULL, NULL, 4, 'bearcat', NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tUserRank`
--

CREATE TABLE IF NOT EXISTS `tUserRank` (
  `UserRankID` int(11) NOT NULL,
  `UserRankName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `UploadAssignment` tinyint(1) NOT NULL,
  `ViewAssignment` tinyint(1) NOT NULL,
  `DownloadAssignment` tinyint(1) NOT NULL,
  `SearchAssignment` tinyint(1) NOT NULL,
  `ModifyAssignmentTag` tinyint(1) NOT NULL,
  `MaintainSecurity` tinyint(1) NOT NULL,
  `SuperUser` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tUserRank`
--

INSERT INTO `tUserRank` (`UserRankID`, `UserRankName`, `UploadAssignment`, `ViewAssignment`, `DownloadAssignment`, `SearchAssignment`, `ModifyAssignmentTag`, `MaintainSecurity`, `SuperUser`) VALUES
(1, 'Admin', 1, 1, 1, 1, 1, 1, 1),
(2, 'SubjectAdmin', 1, 1, 1, 1, 1, 0, 0),
(3, 'Faculty', 1, 1, 1, 1, 0, 0, 0),
(4, 'ReadOnly', 0, 1, 0, 1, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tAssignment`
--
ALTER TABLE `tAssignment`
  ADD PRIMARY KEY (`AssignmentID`), ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `tAssignment_Course`
--
ALTER TABLE `tAssignment_Course`
  ADD UNIQUE KEY `Assignment_Primary_Courses_ID` (`Assignment_CourseID`);

--
-- Indexes for table `tAssignment_IntermediateSSC`
--
ALTER TABLE `tAssignment_IntermediateSSC`
  ADD PRIMARY KEY (`Assignment_IntermediateSSCID`), ADD KEY `SubjectID` (`SubjectID`), ADD KEY `FocusSubjectID` (`FocusSubjectID`), ADD KEY `SpecialtyID` (`SpecialtyID`), ADD KEY `FocusSpecialtyID` (`FocusSpecialtyID`), ADD KEY `CourseID` (`CourseID`), ADD KEY `FocusCourseID` (`FocusCourseID`), ADD KEY `AssignmentID` (`AssignmentID`);

--
-- Indexes for table `tAssignment_Specialty`
--
ALTER TABLE `tAssignment_Specialty`
  ADD UNIQUE KEY `Assignment_Primary_Specialty_ID` (`Assignment_SpecialtyID`);

--
-- Indexes for table `tAssignment_Subject`
--
ALTER TABLE `tAssignment_Subject`
  ADD PRIMARY KEY (`Assignment_SubjectID`), ADD UNIQUE KEY `Assignment_Primary_Subject_ID` (`Assignment_SubjectID`);

--
-- Indexes for table `tCourse`
--
ALTER TABLE `tCourse`
  ADD PRIMARY KEY (`CourseID`);

--
-- Indexes for table `tSecurityQuestion`
--
ALTER TABLE `tSecurityQuestion`
  ADD PRIMARY KEY (`SecurityQuestionID`);

--
-- Indexes for table `tSpecialty`
--
ALTER TABLE `tSpecialty`
  ADD PRIMARY KEY (`SpecialtyID`);

--
-- Indexes for table `tSubject`
--
ALTER TABLE `tSubject`
  ADD PRIMARY KEY (`SubjectID`);

--
-- Indexes for table `tUser`
--
ALTER TABLE `tUser`
  ADD PRIMARY KEY (`UserID`), ADD UNIQUE KEY `Email` (`Email`), ADD KEY `SecurityQuestionID` (`SecurityQuestionID`), ADD KEY `UserRankID` (`UserRankID`);

--
-- Indexes for table `tUserRank`
--
ALTER TABLE `tUserRank`
  ADD PRIMARY KEY (`UserRankID`), ADD UNIQUE KEY `UserRankName` (`UserRankName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tAssignment`
--
ALTER TABLE `tAssignment`
  MODIFY `AssignmentID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT for table `tAssignment_IntermediateSSC`
--
ALTER TABLE `tAssignment_IntermediateSSC`
  MODIFY `Assignment_IntermediateSSCID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=297;
--
-- AUTO_INCREMENT for table `tAssignment_Subject`
--
ALTER TABLE `tAssignment_Subject`
  MODIFY `Assignment_SubjectID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tCourse`
--
ALTER TABLE `tCourse`
  MODIFY `CourseID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `tSecurityQuestion`
--
ALTER TABLE `tSecurityQuestion`
  MODIFY `SecurityQuestionID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tSpecialty`
--
ALTER TABLE `tSpecialty`
  MODIFY `SpecialtyID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `tSubject`
--
ALTER TABLE `tSubject`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=312;
--
-- AUTO_INCREMENT for table `tUser`
--
ALTER TABLE `tUser`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `tUserRank`
--
ALTER TABLE `tUserRank`
  MODIFY `UserRankID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tAssignment`
--
ALTER TABLE `tAssignment`
ADD CONSTRAINT `tAssignment_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `tUser` (`UserID`);

--
-- Constraints for table `tAssignment_IntermediateSSC`
--
ALTER TABLE `tAssignment_IntermediateSSC`
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_7` FOREIGN KEY (`AssignmentID`) REFERENCES `tAssignment` (`AssignmentID`),
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_1` FOREIGN KEY (`SubjectID`) REFERENCES `tSubject` (`SubjectID`),
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_2` FOREIGN KEY (`FocusSubjectID`) REFERENCES `tSubject` (`SubjectID`),
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_3` FOREIGN KEY (`SpecialtyID`) REFERENCES `tSpecialty` (`SpecialtyID`),
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_4` FOREIGN KEY (`FocusSpecialtyID`) REFERENCES `tSpecialty` (`SpecialtyID`),
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_5` FOREIGN KEY (`CourseID`) REFERENCES `tCourse` (`CourseID`),
ADD CONSTRAINT `tAssignment_IntermediateSSC_ibfk_6` FOREIGN KEY (`FocusCourseID`) REFERENCES `tCourse` (`CourseID`);

--
-- Constraints for table `tUser`
--
ALTER TABLE `tUser`
ADD CONSTRAINT `tUser_ibfk_1` FOREIGN KEY (`SecurityQuestionID`) REFERENCES `tSecurityQuestion` (`SecurityQuestionID`),
ADD CONSTRAINT `tUser_ibfk_2` FOREIGN KEY (`UserRankID`) REFERENCES `tUserRank` (`UserRankID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
