-- phpMyAdmin SQL Dump
-- version 4.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 11, 2016 at 03:00 PM
-- Server version: 5.5.42-37.1
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mzc_group3`
--

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment`
--

CREATE TABLE IF NOT EXISTS `tAssignment` (
  `AssignmentID` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Comments` tinyblob NOT NULL,
  `File` blob NOT NULL,
  `WillBeGraded` char(1) NOT NULL,
  `RubricIncluded` char(1) NOT NULL,
  `DateTimeUploaded` datetime NOT NULL,
  `UserID_Uploaded` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_Course`
--

CREATE TABLE IF NOT EXISTS `tAssignment_Course` (
  `Assignment_CourseID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_Specialty`
--

CREATE TABLE IF NOT EXISTS `tAssignment_Specialty` (
  `Assignment_SpecialtyID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `SpecialtyID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tAssignment_Subject`
--

CREATE TABLE IF NOT EXISTS `tAssignment_Subject` (
  `Assignment_SubjectID` int(11) NOT NULL,
  `AssignmentID` int(11) NOT NULL,
  `SubjectID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tCourse`
--

CREATE TABLE IF NOT EXISTS `tCourse` (
  `Course_ID` int(11) NOT NULL,
  `Course` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tCourse`
--

INSERT INTO `tCourse` (`Course_ID`, `Course`) VALUES
(1, 'ENG1001'),
(2, 'IT1020'),
(3, 'CHEM1001');

-- --------------------------------------------------------

--
-- Table structure for table `tSecurityQuestion`
--

CREATE TABLE IF NOT EXISTS `tSecurityQuestion` (
  `SecurityQuestionID` int(11) NOT NULL,
  `SecurityQuestion` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tSecurityQuestion`
--

INSERT INTO `tSecurityQuestion` (`SecurityQuestionID`, `SecurityQuestion`) VALUES
(1, 'What was the name of your first pet?'),
(3, 'What was the name of your last pet?'),
(4, 'What was the mascot of your High School?'),
(5, 'Who was your favorite teacher in High School?'),
(6, 'What was your favorite place to vacation as a child?');

-- --------------------------------------------------------

--
-- Table structure for table `tSpecialty`
--

CREATE TABLE IF NOT EXISTS `tSpecialty` (
  `SpecialtyID` int(11) NOT NULL,
  `Specialty` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tSpecialty`
--

INSERT INTO `tSpecialty` (`SpecialtyID`, `Specialty`) VALUES
(1, 'Excel'),
(2, 'Charts'),
(3, 'pie graph');

-- --------------------------------------------------------

--
-- Table structure for table `tSubject`
--

CREATE TABLE IF NOT EXISTS `tSubject` (
  `SubjectID` int(11) NOT NULL,
  `Subject` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tSubject`
--

INSERT INTO `tSubject` (`SubjectID`, `Subject`) VALUES
(1, 'Information Technology'),
(2, 'Psychology'),
(3, 'Math'),
(4, 'Chemistry'),
(5, 'English');

-- --------------------------------------------------------

--
-- Table structure for table `tUser`
--

CREATE TABLE IF NOT EXISTS `tUser` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(25) NOT NULL,
  `LastName` varchar(35) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Bio` tinyblob,
  `Password` varchar(100) NOT NULL,
  `OfficeHours` varchar(250) DEFAULT NULL,
  `RoomNum` varchar(25) DEFAULT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `PreferredContactMethod` varchar(25) DEFAULT NULL,
  `SecurityQuestionID` int(11) NOT NULL,
  `SecurityQuestionAnswer` varchar(250) DEFAULT NULL,
  `LastLoginTime` datetime DEFAULT NULL,
  `FailedLoginAttempts` int(11) DEFAULT NULL,
  `UserRankID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tUser`
--

INSERT INTO `tUser` (`UserID`, `FirstName`, `LastName`, `Email`, `Bio`, `Password`, `OfficeHours`, `RoomNum`, `Phone`, `PreferredContactMethod`, `SecurityQuestionID`, `SecurityQuestionAnswer`, `LastLoginTime`, `FailedLoginAttempts`, `UserRankID`) VALUES
(3, 'Patrick', 'Voto', 'votopj@mail.uc.edu', NULL, '', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, 1),
(8, 'Zach', 'Janzen', 'janzenz09@gmail.com', NULL, 'd4705b9f42c96eeb0b9fb53266013516', NULL, NULL, NULL, NULL, 4, 'Eagle', NULL, NULL, 1),
(42, 'Justin', 'Tyler', 'tylerjn@mail.uc.edu', NULL, '8213a17a3549677baddf3b2289c5a144', NULL, NULL, NULL, NULL, 1, 'haha', NULL, NULL, 3),
(43, 'bob', 'thebuilder', 'bob@building.com', NULL, '95dd7f86353b250683cca89eed4e1838', NULL, NULL, NULL, NULL, 4, 'hammer', NULL, NULL, 3),
(44, 'Ben', 'Ward', 'benstopics@gmail.com', NULL, '05a671c66aefea124cc08b76ea6d30bb', NULL, NULL, NULL, NULL, 42, '42', NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tUserRank`
--

CREATE TABLE IF NOT EXISTS `tUserRank` (
  `UserRankID` int(11) NOT NULL,
  `UserRankName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `UploadAssignment` tinyint(1) NOT NULL,
  `ViewAssignment` tinyint(1) NOT NULL,
  `DownloadAssignment` tinyint(1) NOT NULL,
  `SearchAssignment` tinyint(1) NOT NULL,
  `ModifyAssignmentTag` tinyint(1) NOT NULL,
  `MaintainSecurity` tinyint(1) NOT NULL,
  `SuperUser` tinyint(1) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tUserRank`
--

INSERT INTO `tUserRank` (`UserRankID`, `UserRankName`, `UploadAssignment`, `ViewAssignment`, `DownloadAssignment`, `SearchAssignment`, `ModifyAssignmentTag`, `MaintainSecurity`, `SuperUser`) VALUES
(1, 'Admin', 1, 1, 1, 1, 1, 1, 1),
(2, 'SubjectAdmin', 1, 1, 1, 1, 1, 0, 0),
(3, 'Faculty', 1, 1, 1, 1, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tAssignment`
--
ALTER TABLE `tAssignment`
  ADD PRIMARY KEY (`AssignmentID`), ADD KEY `User_ID_Uploaded` (`UserID_Uploaded`);

--
-- Indexes for table `tAssignment_Course`
--
ALTER TABLE `tAssignment_Course`
  ADD UNIQUE KEY `Assignment_Primary_Courses_ID` (`Assignment_CourseID`);

--
-- Indexes for table `tAssignment_Specialty`
--
ALTER TABLE `tAssignment_Specialty`
  ADD UNIQUE KEY `Assignment_Primary_Specialty_ID` (`Assignment_SpecialtyID`);

--
-- Indexes for table `tAssignment_Subject`
--
ALTER TABLE `tAssignment_Subject`
  ADD UNIQUE KEY `Assignment_Primary_Subject_ID` (`Assignment_SubjectID`);

--
-- Indexes for table `tCourse`
--
ALTER TABLE `tCourse`
  ADD UNIQUE KEY `Course_ID` (`Course_ID`);

--
-- Indexes for table `tSecurityQuestion`
--
ALTER TABLE `tSecurityQuestion`
  ADD UNIQUE KEY `Security_Question_ID` (`SecurityQuestionID`);

--
-- Indexes for table `tSpecialty`
--
ALTER TABLE `tSpecialty`
  ADD UNIQUE KEY `Specialty_ID` (`SpecialtyID`);

--
-- Indexes for table `tSubject`
--
ALTER TABLE `tSubject`
  ADD UNIQUE KEY `Subject_ID` (`SubjectID`);

--
-- Indexes for table `tUser`
--
ALTER TABLE `tUser`
  ADD PRIMARY KEY (`UserID`), ADD UNIQUE KEY `User_ID` (`UserID`), ADD UNIQUE KEY `Email` (`Email`), ADD KEY `Email_2` (`Email`);

--
-- Indexes for table `tUserRank`
--
ALTER TABLE `tUserRank`
  ADD PRIMARY KEY (`UserRankID`), ADD UNIQUE KEY `UserRankName` (`UserRankName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tAssignment`
--
ALTER TABLE `tAssignment`
  MODIFY `AssignmentID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tCourse`
--
ALTER TABLE `tCourse`
  MODIFY `Course_ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tSecurityQuestion`
--
ALTER TABLE `tSecurityQuestion`
  MODIFY `SecurityQuestionID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tSpecialty`
--
ALTER TABLE `tSpecialty`
  MODIFY `SpecialtyID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tSubject`
--
ALTER TABLE `tSubject`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tUser`
--
ALTER TABLE `tUser`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `tUserRank`
--
ALTER TABLE `tUserRank`
  MODIFY `UserRankID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
